# Article data — affordable microwave dielectric spectroscopy system

Data behind the article *Affordable microwave dielectric spectroscopy system* (Steen, Kjelgård and Hou,
Journal of Electrical Bioimpedance). Every sample was measured back-to-back on the affordable system (DSS:
LibreVNA + custom probe P1) and on the reference (SPEAG DAKS-3.5 probe on an R140 reflectometer), from
the same beaker. All liquids at 20 °C except the isopropanol mixtures (warmer from mixing).

| Day | Date | DSS connection | Samples in the article |
|---|---|---|---|
| Day 1 (`session2`) | 2026-10-31 | probe through a 1.83 m cable (Mini-Circuits CBN-6FT-SMSM+) | ethanol 48 % (`eth-48-2`), 24 %, 12 %; isopropanol 99, 50, 25, 12 % |
| Day 2 (`session3`) | 2026-11-01 | probe directly on the LibreVNA port | saline 1:3 (`saline-1-3`), AdBlue, GABA 0.1/0.5/1 mol/kg (`gaba-01/05/1`) |

Also in the folders, but not compared in the article: `eth-33`, `eth-66`, `eth-96`, `eth-48` (air bubble; redone
as `eth-48-2`), `saline` (0.9 % NaCl, a calibration standard), `air-test`/`water-test` (test calibration on day 2).

## Layout

```
article-data/
├── DSS_LibreVNA/                       DSS sweeps as written by the DSS software, unchanged
│   ├── session2_cal-20C/               day 1: one folder per sample, 5 sweeps each (eth-48-2: 4)
│   └── session3_2026-11-01_nocable_cal-20C/   day 2
│       (air-/short-/water-start and -end = start and end snapshots; calibration.cal = the probe-tip calibration)
├── DSS_LibreVNA_drift-corrected/
│   └── session2_cal-20C/               day 1 after the DSS software's drift correction (DSS 0.4.5,
│                                       start/end snapshots, linear in time); cleanup_report.txt lists the pairing
├── R140_raw/                           reference exports from the DAK software (.xlsx, 3 repeats = 3 sheets)
│   ├── session2/
│   └── session3/
├── R140_csv/                           the same reference data as CSV, one file per repeat (<sample>_b<n>.csv)
│   ├── session2/  session3/
│   └── index.csv                       source sheet, time, DAK temperature setting and notes per file
└── standards/
    └── meas-P1-ethanol96-22p5c.s2p     4th standard of the 4-standard method (see below)
```

## Formats

- **DSS `.s2p`**: the custom extended Touchstone format described in the repository README: `!` comments
  (date, sample, probe, calibration temperature, filter), `#` header, then per row
  `Frequency S11_Real S11_Imag Perm_Real Perm_Imag Conductivity LossTan R X`, 0.2–6 GHz, 2071 points.
  The S11 columns are the calibrated probe-tip reflection coefficient. The Perm columns in `DSS_LibreVNA/` are
  the software's own output; the article recomputes the permittivity from S11 with both methods. In
  `DSS_LibreVNA_drift-corrected/` both S11 and Perm are corrected (Perm with the 4-standard method).
- **R140 CSV**: `freq_hz, eps_real, eps_imag, sigma_s_per_m, tan_delta, gamma_re, gamma_im`, 0.1–10 GHz in
  10 MHz steps; `eps* = eps_real - j*eps_imag`. Values are unchanged from the `.xlsx` (MHz converted to Hz).
  The DAK temperature setting was 23 °C until 2026-10-31 18:05:31 and 20 °C after (column
  `dak_temp_setting_c` in `index.csv`). Some buffers are flagged in the `note` column.
- Permittivity convention everywhere: `eps* = eps' - j*eps''`, with `eps''` stored positive.

## Calibration standards

- 3-standard method: open (air), DI water and saltwater (0.9 % NaCl), simulated in CST at 20 °C:
  `sim-P1-open.s2p`, `sim-P1-DI_water-20c.s2p`, `sim-P1-saltwater-20c.s2p` in `data.zip`
  (`data/calibration-standards/`), the same files used here. The short (`sim-P1-short.s2p`) is used in the
  probe-tip calibration.
- 4-standard method: adds 96 % ethanol. Only the **S11** of `standards/meas-P1-ethanol96-22p5c.s2p` is used (a
  single LibreVNA measurement at 22.5 °C); its permittivity is taken from the Sato and Buchner model at 22.5 °C
  (J. Phys. Chem. A 108 (2004) 5007–5015), not from the Perm columns of that file.
