# Data — measurements behind the thesis results

The measurement sets that back the Chapter 4 results. All files are the custom
`.s2p` format documented in `../software/README.md` (freq, S11, and stored
permittivity). Read them with `software/s11_to_permittivity.py`.

```
data/
├── measurements/          measurement sessions by temperature
│   ├── 10c/   {aff,ref}    affordable system vs. commercial reference at 10 C
│   ├── 22p5c/ {aff,ref}    ... at 22.5 C (the main session)
│   └── 35c/   {aff,ref}    ... at 35 C
├── method/                the four extraction methods applied to the 22.5 C set
│                          (Scalar C0, Vector C0, Capacitive, Bilinear)
└── reference-permittivity/ input of the LabVIEW compare-permittivity GUI (see its README.md)
    ├── Compare/            DSS (LibreVNA + probe P1) per liquid, in Ethanol/, Isopropanol/, Other/
    ├── Ideal/              NN-<name>: P1 calibration standards (00, 01, 02, 06) + R140 references
    ├── association.txt     the GUI's "Association set" for these files
    └── pairs.csv           the same pairs with names
```

`aff` = affordable system (custom OECP + LibreVNA); `ref` = commercial reference
system. The one-time-simulated calibration standards live one level up in
`../calibration-standards/`.

Not included here: the raw per-sweep dumps (five sweeps averaged into each trace)
and the side-analysis datasets (de-embedding, expensive-probe comparison). Ask if
you want those added.
