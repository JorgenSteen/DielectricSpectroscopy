# reference-permittivity: input of RDV-GUI-Compare_Permittivity_calc.vi

Built by `software/python/build_reference_permittivity.py` from `article-data/` and
`data/calibration-standards/`. Rebuild with that script; do not edit the files by hand.

```
reference-permittivity/
├── Ideal/            NN-<name>.s2p         GUI control "reference paths"
├── Compare/          P1_<liquid>.s2p       GUI control "Files for analyses"
├── association.txt   GUI control "Association set" (paste the line in)
└── pairs.csv         the same pairs, readable: measured, reference, indices
```

## Why the numbers

The GUI sorts every key alphabetically and finds files by POSITION in that list:
- the first N keys (N = number of Ideal files) are the references; the permittivity methods take the
  calibration standards from them by fixed position: **open 00, short 01, water 02, saline 06**;
- the rest are the Compare files, four keys each (one per calculation method);
- the "Association set" pairs a reference index with a set index.

So the Ideal files carry a two-digit number (two digits keep 10+ files in order), the standards sit in
their fixed slots, and every Compare file name must sort after the numbers (it starts with a letter).

| Slot | File | What |
|---|---|---|
| 00 | `00-open.s2p` | calibration standard (simulated P1, 20 C) |
| 01 | `01-short.s2p` | calibration standard (simulated P1, 20 C) |
| 02 | `02-water.s2p` | calibration standard (simulated P1, 20 C) |
| 03 | `03-adblue.s2p` | R140 reference |
| 04 | `04-eth-12.s2p` | R140 reference |
| 05 | `05-eth-24.s2p` | R140 reference |
| 06 | `06-saline.s2p` | calibration standard (simulated P1, 20 C) |
| 07 | `07-eth-33.s2p` | R140 reference |
| 08 | `08-eth-48.s2p` | R140 reference |
| 09 | `09-eth-66.s2p` | R140 reference |
| 10 | `10-eth-96.s2p` | R140 reference |
| 11 | `11-gaba-01.s2p` | R140 reference |
| 12 | `12-gaba-05.s2p` | R140 reference |
| 13 | `13-gaba-1.s2p` | R140 reference |
| 14 | `14-iso-12.s2p` | R140 reference |
| 15 | `15-iso-25.s2p` | R140 reference |
| 16 | `16-iso-50.s2p` | R140 reference |
| 17 | `17-iso-99.s2p` | R140 reference |
| 18 | `18-saline-0p9.s2p` | R140 reference |
| 19 | `19-saline-1-3.s2p` | R140 reference |

## Rules when adding files

1. Ideal: next free two-digit number, `NN-<name>.s2p`; never move 00, 01, 02, 06.
2. Compare: `<probe>_<liquid>.s2p`, starting with a letter. No liquid name may be another liquid name
   followed by `-<digit>` (for example `saline` and `saline-1-3`): their method keys would interleave.
3. Rerun the script (or recount by hand) and paste the new `association.txt` into the GUI.

## Grids and columns

Every file has the DSS grid (0.2-6 GHz, 2071 points): the LabVIEW calculations work point by point.
Columns: `Frequency S11_Real S11_Imag Perm_Real Perm_Imag Conductivity LossTan R X`,
`eps* = eps' - j*eps''` with `eps''` positive. R140 references have S11, R and X = 0 (not measured
with probe P1).

## Sources

Day 1 (2026-10-31): drift-corrected DSS sweeps; day 2 (2026-11-01): DSS sweeps as recorded.
`P1_eth-48-2` is the DSS remeasure of the `eth-48` beaker. `saline-0p9` is the 0.9 % NaCl liquid
(article folder `saline`), renamed so it cannot interleave with `saline-1-3`. See `article-data/README.md`.
